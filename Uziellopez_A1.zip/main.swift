var Numero:Int;
print("Escribe el número: ")
Numero = Int(readLine()!)!
if Numero % 2 == 0 {
    print("El número es par")
}
else{
    print("El número es impar")
}